import RPi.GPIO as GPIO
import time
from subprocess import call


gpio_pin = 12

GPIO.setmode(GPIO.BOARD)
GPIO.setup(gpio_pin, GPIO.IN, pull_up_down=GPIO.PUD_UP)
GPIO.setup(16,GPIO.OUT)

GPIO.output(16,GPIO.LOW)

def button_callback(pin):
	print 'Pushed'
	call(["node", "run_camera.js"])
	GPIO.output(16,GPIO.HIGH)
	time.sleep(2)
	GPIO.output(16,GPIO.LOW)

try:
	# apply 100ms debounce
	GPIO.add_event_detect(gpio_pin, GPIO.FALLING, callback=button_callback, bouncetime=300)

	print 'Start listening'
	# listen 20 seconds for events to be fired
	time.sleep(20)

finally:
	GPIO.remove_event_detect(gpio_pin)

	print 'Stop listening'
	GPIO.cleanup()
